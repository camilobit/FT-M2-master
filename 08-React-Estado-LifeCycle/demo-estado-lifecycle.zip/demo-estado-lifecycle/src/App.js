
import './App.css';
import Contador from './components/Contador';
import Counter from './components/Counter';

function App() {
  return (
    <div className="App">
      <Contador/>
      <hr></hr>
      <Counter/>
    </div>
  );
}

export default App;
